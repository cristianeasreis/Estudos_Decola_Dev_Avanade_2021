# Projeto_design_patterns_Com_C#

Aplicando design patterns na prática com C#

Neste projeto aprenda a desenvolver aplicações em C# 
confiáveis e estruturadas com as melhores práticas do mercado.

ESPECIALISTA

Victor Fructuoso
Manager Tech, Avanade

# Atividades Extras Curriculares

Bom os meus projetos feito no SENAC - SÃO MIGUEL PAULISTA 

"TCC DESKTOP - https://github.com/cristianeasreis/TCC_Senac_AppDesktopFerrari"

"TCC APPMOBILE - https://github.com/cristianeasreis/TCC_Senac_AppMobile_Cordova"

"TCC WEB - https://github.com/cristianeasreis/TCC_Senac_Web"



